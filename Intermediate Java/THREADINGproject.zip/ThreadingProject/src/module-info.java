module ThreadingProject {
	requires java.desktop; 
}