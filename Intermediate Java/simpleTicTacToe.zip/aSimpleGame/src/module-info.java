module aSimpleGame {
	requires java.desktop;
}