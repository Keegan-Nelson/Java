package Assign4;
import java.util.Scanner; 
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		linkedList L = new linkedList(); 
		System.out.println("Enter 10 Numbers:");
		for(int i = 0; i < 10; i++) {
		Scanner input = new Scanner(System.in);
		int num = 0; 
		L.addNode(num, input.nextInt());
		num++;
		}
		L.traverseNodes();	
		Scanner delete = new Scanner(System.in);
		System.out.println("Enter 2 Numbers to delete from list: ");
		for(int i = 0; i <2; i++) {
			L.removeNode(delete.nextInt());
		}
		L.traverseNodes();
	}
}
