module Test {
	requires java.desktop; 
}