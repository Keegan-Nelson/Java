package test;

public class main {

	GUI g = new GUI(); 
}
