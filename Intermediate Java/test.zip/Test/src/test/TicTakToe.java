package test;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class TicTakToe extends JFrame {

	//displayBoard is considered a matrix 
	// it will look like this 
//	[0 1 2]
//	[3 4 5]
//	[6 7 8]
							
	Object[][][] displayBoard ; 
	public TicTakToe() { 
		
		JFrame frame = new JFrame("TicTakToe"); 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300,300); 
		 
		
		JPanel panel = new JPanel(); 
		frame.getContentPane().add(panel); 
	}
	
	public void clearBoard() {
		
	}
	public void displayBoard() { 
		
	}
	public boolean isBoardFull() { 
		
		return false;
	}
}

