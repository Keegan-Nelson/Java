package Tree;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HeapTree HP = new HeapTree(); 
		HP.add(19);
		HP.add(8);
		HP.add(22);
		HP.add(12);
		HP.add(16);
		HP.add(5);
		HP.add(7);
		HP.add(20);
		HP.add(14);
		HP.add(2);
		HP.add(11);
		HP.add(21);
		HP.displayHeap();
	}

}
