package Tree;

public class HeapTree {
private int nextElement = 0; 
private Object[] theArray = new Object[20];

	public void add(Object obj) {
		theArray[nextElement] = obj; 
		int currentElement = nextElement;
		nextElement++; 
		Object temp; 
		int parentElement = (currentElement-1)/2;
	
		while(currentElement > 0 && ((Comparable)theArray[currentElement]).compareTo(theArray[parentElement]) < 0) {
		
			temp = theArray[currentElement];
			theArray[currentElement] = theArray[parentElement]; 
			theArray[parentElement] = temp; 
		
			currentElement = parentElement; 
			parentElement = (currentElement-1)/2;
		}
	}
	public void displayHeap() { 
		for(int i = 0; i< theArray.length; i++) {
			
			System.out.println(theArray[i]);
		}
	}
}