package tProject;

import javax.swing.*; 
import java.awt.*; 

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//GUI g = new GUI(); 
		GUI g = new GUI(); 
	}

}
